# Contentstack | Auto Image Tagging (AWS Rekognition)
Auto image tagging setup tags an asset of type image whenever created or updated in a Stack using AWS Rekognition and lambda (png and jpg only supported by AWS Rekognition).

## Steps

 1. Create AWS user
 2. Create Contentstack user role
 3. Setup lambda function and api gateway
 4. Setup Contenstack webhook

## Configuration

### AWS

#### ReKognition

 1. Create AWS User with programmatic access
 2. Add **AmazonRekognitionReadOnlyAccess** (*AWS managed policy*)
   permission policy to user 
 3. Create access key and secrete for the user, this credentials we would use to access AWS rekognition service from the lambda function

#### Lambda

 - Create a new lambda function which can be triggered by api gateway 
 - Use the index.zip file present in root folder of the current repo as AWS lambda code and add the following environment variable
 
 **Aws Lambda Environment Variables**
 
 - **REKOGNITION_AWS_ID** = access id of aws user | ***required***
 - **REKOGNITION_AWS_REGION**= aws region | ***required***
 - **REKOGNITION_AWS_SECRET**=access key of aws user | ***required***
 - **MIN_CONFIDENCE**= minimum confidence of tag | ***default 70***
 - **MAX_TAGS**= maximum tags per image | ***default 10***
 - **CONTENTSTACK_STACK_MANAGEMENT_TOKEN**= contentstack stack management token
 - **CONTENTSTACK_STACK_API_KEY**= contentstack stack api key

### Contentstack

#### Stack Management Token
 - Create stack management token with read and write permissions.

#### Webhook
 
 - Create webhook which will trigger AWS lambda function with appropriate AWS  api gateway url  and x-api-key header for access control (if access key is  required)
 - Webhook shall trigger on Asset create or update event
