# Contentstack | Auto Publish Entry
Auto publish for entry on update or create on desired environment(s).

## Steps

 1. Create Contentstack stack management token
 2. Setup AWS lambda function and api gateway
 3. Setup Contenstack webhook

## Configuration

### AWS

#### Lambda

 - Create a new lambda function which can be triggered by api gateway 
 - Use the index.zip file present in root folder of the current repo as AWS lambda code and add the following environment variable
 
 **Aws Lambda Environment Variables**
 
 - **CONTENTSTACK_STACK_MANAGEMENT_TOKEN**= contentstack stack management token
 - **CONTENTSTACK_STACK_API_KEY**= contentstack stack api key

### Contentstack

#### Stack Management Token
 - Create stack management token with read and write permissions.

#### Webhook
 
 - Create webhook which will trigger AWS lambda function with appropriate AWS  api gateway url  and x-api-key header for access control (if access key is  required)
 - Set conditions to trigger on for when all entries of any contenttype created or updated
 - Add custom header with parameter ***target_environments***  and value as comma separated list of environments where we need to publish. Eg. ***stage,pre-prod***